﻿using MarsRoverApp.Enums;
using MarsRoverApp.Helpers;
using MarsRoverApp.Mars;
using MarsRoverApp.NASACommands;
using System;
using System.Collections.Generic;

namespace MarsRoverApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PlateauSize plateauSize = new PlateauSize(5, 5);
            List<RoverCommands> roverCommands = new List<RoverCommands>()
                {
                    new RoverCommands(
                        new RoverPosition(1, 2, Enums.Orientation.North),
                        new List<Movement>()
                        {
                            Movement.Left,
                            Movement.Move,
                            Movement.Left,
                            Movement.Move,
                            Movement.Left,
                            Movement.Move,
                            Movement.Left,
                            Movement.Move,
                            Movement.Move
                        }
                    ),
                    new RoverCommands(
                        new RoverPosition(3, 3, Enums.Orientation.East),
                        new List<Movement>()
                        {
                            Movement.Move,
                            Movement.Move,
                            Movement.Right,
                            Movement.Move,
                            Movement.Move,
                            Movement.Right,
                            Movement.Move,
                            Movement.Right,
                            Movement.Right,
                            Movement.Move

                        }
                    )
                };
            Plateau plateau = new Plateau(plateauSize, roverCommands);
            foreach (Rover rover in plateau.Rovers)
            {
                Console.WriteLine($"{rover._RoverPosition.X} {rover._RoverPosition.Y} {rover._RoverPosition.Orientation}");
            }
        }
    }
}
