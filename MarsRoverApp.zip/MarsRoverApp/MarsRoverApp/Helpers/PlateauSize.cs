﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarsRoverApp.Helpers
{
    public class PlateauSize
    {
        public int _MaxXCoordinates { get; set; }
        public int _MaxYCoordinates { get; set; }
        public PlateauSize(int maxXCoordinates, int maxYCoordinates)
        {
            _MaxXCoordinates = maxXCoordinates;
            _MaxYCoordinates = maxYCoordinates;

        }
    }
}
