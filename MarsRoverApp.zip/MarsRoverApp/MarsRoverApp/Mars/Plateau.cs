﻿using MarsRoverApp.Enums;
using MarsRoverApp.Helpers;
using MarsRoverApp.NASACommands;
using System.Collections.Generic;

namespace MarsRoverApp.Mars
{
    public class Plateau
    {
        public PlateauSize _PlateauSize { get; set; }
        public List<Rover> Rovers { get; set; }
        public Plateau(PlateauSize plateauSize, List<RoverCommands> roverCommands)
        {
            _PlateauSize = plateauSize;
            Rovers = new List<Rover>();
            foreach (RoverCommands roverCommand in roverCommands)
            {
                Rover rover = new Rover(roverCommand._InitialRoverPosition);
                foreach (Movement movement in roverCommand._Commands)
                {
                    rover.Move(movement, _PlateauSize);
                }
                Rovers.Add(rover);
            }
        }
    }
}
