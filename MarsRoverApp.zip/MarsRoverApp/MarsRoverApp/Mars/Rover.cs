﻿using MarsRoverApp.Enums;
using MarsRoverApp.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace MarsRoverApp.Mars
{
    public class Rover
    {
        public RoverPosition _RoverPosition { get; set; }
        public Rover(RoverPosition InitialRoverPosition)
        {
            _RoverPosition = InitialRoverPosition;
        }
        public void Move(Movement command, PlateauSize plateauSize)
        {
            switch (command)
            {
                case Movement.Right:
                    switch (_RoverPosition.Orientation)
                    {
                        case Orientation.North:
                            _RoverPosition.Orientation = Orientation.East;
                            break;
                        case Orientation.East:
                            _RoverPosition.Orientation = Orientation.South;
                            break;
                        case Orientation.South:
                            _RoverPosition.Orientation = Orientation.West;
                            break;
                        case Orientation.West:
                            _RoverPosition.Orientation = Orientation.North;
                            break;
                    }
                    break;
                case Movement.Left:
                    switch (_RoverPosition.Orientation)
                    {
                        case Orientation.North:
                            _RoverPosition.Orientation = Orientation.West;
                            break;
                        case Orientation.West:
                            _RoverPosition.Orientation = Orientation.South;
                            break;
                        case Orientation.South:
                            _RoverPosition.Orientation = Orientation.East;
                            break;
                        case Orientation.East:
                            _RoverPosition.Orientation = Orientation.North;
                            break;
                    }
                    break;
                case Movement.Move:
                    switch (_RoverPosition.Orientation)
                    {
                        case Orientation.North:
                            if (_RoverPosition.Y < plateauSize._MaxYCoordinates)
                            {
                                _RoverPosition.Y += 1; 
                            }
                            break;
                        case Orientation.West:
                            if (_RoverPosition.X > 0)
                            {
                                _RoverPosition.X -= 1;
                            }
                            break;
                        case Orientation.South:
                            if (_RoverPosition.Y > 0)
                            {
                                _RoverPosition.Y -= 1;
                            }
                            break;
                        case Orientation.East:
                            if (_RoverPosition.X < plateauSize._MaxXCoordinates)
                            {
                                _RoverPosition.X += 1;
                            }
                            break;
                    }
                    break;
            }
        }
    }
}
