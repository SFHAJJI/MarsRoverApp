﻿using MarsRoverApp.Enums;
using MarsRoverApp.Helpers;
using System.Collections.Generic;

namespace MarsRoverApp.NASACommands
{
    public class RoverCommands
    {
        public RoverPosition _InitialRoverPosition { get; set; }
        public List<Movement> _Commands { get; set; }
        public RoverCommands(RoverPosition initialRoverPosition, List<Movement> commands)
        {
            _InitialRoverPosition = initialRoverPosition;
            _Commands = commands;

        }
    }
}
