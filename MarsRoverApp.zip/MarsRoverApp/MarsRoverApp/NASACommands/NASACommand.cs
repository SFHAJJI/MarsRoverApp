﻿using MarsRoverApp.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace MarsRoverApp.NASACommands
{
    public class NASACommand
    {
        PlateauSize InitialPlateauSize { get; set; }
        List<RoverCommands> RoverCommandsList { get; set; }
    }
}
