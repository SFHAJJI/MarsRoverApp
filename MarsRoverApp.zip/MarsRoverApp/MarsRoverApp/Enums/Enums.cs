﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarsRoverApp.Enums
{
    public enum Orientation
    {
         North,
         South,
         East,
         West
    }

    public enum Movement
    {
        Left,
        Right,
        Move
    }
}
